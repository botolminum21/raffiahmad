#!/bin/sh
./korek -a ethash -o stratum+tcp://daggerhashimoto.usa-east.nicehash.com:3353 -u 3E1sBC7FwYprQeEVy7C7a39GJMP9ekeSsz -p x -w jarossangkuli --low-load 1
